<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Register to TODO List App</title>
    </head>
    <body>
        <div id="wrapper">
            <h1>
                Register to TODO List App
            </h1>
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="create">
                <div>
                    <input type="text" placeholder="Username..." name="username">
                </div>
                <div>
                    <input type="password" placeholder="Password..." name="password">
                </div>
                <div>
                    <input type="password" placeholder="Confirm Password..." name="confirm_password">
                </div>
                <div>
                    <input type="text" placeholder="Fullname..." name="fullname">
                </div>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div style="margin-top: 16px,">
                    <input type="submit" value="Register">
                </div>
            </form>
        </div>
    </body>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: darkcyan;
            margin: 0;
            padding: 0;
        }
        h1 {
            align-items: center;
            text-align: center;
        }
        div {
            background-color: darkgrey;
        }
        #wrapper {
           max-width: 480px;
           width: 100%;
           margin-left: auto;
           margin-right: auto;
           margin-top: 64px;
           border: 1px solid black;
           padding: 16px;
        }
        input {
            width: 100%;
            padding: 8px;
        }
        * {
           box-sizing: border-box; 
        }

    </style>
</html><?php /**PATH C:\laravel\todolist\resources\views/register.blade.php ENDPATH**/ ?>