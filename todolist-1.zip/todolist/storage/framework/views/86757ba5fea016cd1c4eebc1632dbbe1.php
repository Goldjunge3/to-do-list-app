<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit a Task - TODO List App</title>
    </head>
    <body>
        <div id="wrapper">
            <h1>
                Edit a Task - TODO List App
            </h1>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <form action="/update" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" value="<?php echo $task['id'] ?>">
                <div>
                    <input type="text" placeholder="Description..." name="description" value="<?php echo $task['description'] ?>">
                </div>
                <div>
                    <input type="date" name="do_date" value="<?php echo $task['do_date'] ?>">
                </div>
                <div style="margin-top: 16px">
                    <input type="submit" value="Edit">
                </div>
            </form>
        </div>
    </body>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: darkcyan;
            margin: 0;
            padding: 0;
        }
        h1 {
            align-items: center;
            text-align: center;
        }
        div {
            background-color: darkgrey;
        }
        #wrapper {
           max-width: 480px;
           width: 100%;
           margin-left: auto;
           margin-right: auto;
           margin-top: 64px;
           border: 1px solid black;
           padding: 16px;
        }
        input {
            width: 100%;
            padding: 8px;
        }
        * {
           box-sizing: border-box; 
        }

    </style>
</html><?php /**PATH C:\laravel\todolist\resources\views/edit_task.blade.php ENDPATH**/ ?>