<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TODO List App</title>
    </head>
    <body>
        <div id="wrapper">
            <h1>
                TODO List App
            </h1>
            <h3>
                Selamat datang {{ $fullname }}. <a href="{{ url('/logout') }}">Log out.</a>
            </h3>
            @if($errors->any())
                @foreach($errors->all() as $error)
                    <div>{{ $error }}</div>
                @endforeach
            @endif
            <div id="task-list">
                <?php
                    foreach($tasks as $task)
                    {
                ?>
                    <div class="task">
                        <div class="description">
                            <?php echo $task['description'] . '(' . $task['do_date'] . ')' ?>
                        </div>
                        <div class="action">
                            <a href="{{ url('/edit/' . $task['id']) }}">
                                <button>Edit</button>
                            </a>
                            <form action="{{ url('/delete') }}" method="POST">
                                @csrf
                                <input type="hidden" name="id" value="<?php echo $task['id'] ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="submit" value="Delete">
                            </form>
                        </div>
                    </div>
                    <?php
                        }
                    ?>
            </div>
            <form action="{{ url('/add') }}" method="POST">
                @csrf
                <input type="hidden" name="action" value="add">
                <input type="text" name="description">
                <input type="date" name="do_date">
                <input type="submit" value="Add">
            </form>
        </div>
    </body>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: darkcyan;
            margin: 0;
            padding: 0;
        }
        h1 {
            align-items: center;
            text-align: center;
        }
        div {
            background-color: darkgrey;
        }
        .task, .action {
            display: flex;
        }
        .task {
            background-color: grey;
            color: black;
            border-bottom: 1px solid gray;
        }
        .description {
            flex: 1;
            display: flex;
            align-items: center;
            padding-left: 16px;
        }
        #wrapper {
           max-width: 480px;
           width: 100%;
           margin-left: auto;
           margin-right: auto;
           margin-top: 64px;
           border: 1px solid black;
           padding: 16px;
        }
        input, button {
            padding: 8px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        * {
           box-sizing: border-box; 
        }
        form {
            display: flex;
        }
        #task-list {
            min-height: 320px;
            border: 1px solid gray;
            margin-top: 16px;
        }
        input[name="description"] {
            flex: 1
        }
    </style>
</html>