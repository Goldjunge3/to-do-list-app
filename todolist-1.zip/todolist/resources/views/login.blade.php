<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Log in to TODO List App</title>
    </head>
    <body>
        <div id="wrapper">
            <h1>
                Log in to TODO List App
            </h1>
            <form action="" method="POST">
                @csrf
                <input type="hidden" name="action" value="login">
                <div>
                    <input type="text" placeholder="Username..." name="username">
                </div>
                <div>
                    <input type="password" placeholder="Password..." name="password">
                </div>
                @if($errors->any())
                    @foreach($errors->all() as $error)
                    <div>{{ $error }}</div>
                    @endforeach
                @endif
                <div style="margin-top: 16px">
                    <input type="submit" value="Log in">
                </div>
            </form>
        </div>
    </body>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: darkcyan;
            margin: 0;
            padding: 0;
        }
        h1 {
            align-items: center;
            text-align: center;
        }
        div {
            background-color: darkgrey;
        }
        #wrapper {
           max-width: 480px;
           width: 100%;
           margin-left: auto;
           margin-right: auto;
           margin-top: 64px;
           border: 1px solid black;
           padding: 16px;
        }
        input {
            width: 100%;
            padding: 8px;
        }
        input[name="submit"] {
            padding: 8px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer
        }
        * {
           box-sizing: border-box; 
        }

    </style>
</html>